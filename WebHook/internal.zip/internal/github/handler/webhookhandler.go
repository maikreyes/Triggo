package handler

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func (h *Handler) WebhookHandler(ctx *gin.Context) {

	event := strings.TrimSpace(ctx.GetHeader("X-GitHub-Event"))
	body, err := ctx.GetRawData()

	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to request body",
		})
	}

	h.Services.DecodeMessage(event, string(body))

}
