package handler

import "triggo/internal/github/services"

type Handler struct {
	Services services.Services
}

func Newhandler(s services.Services) *Handler {
	return &Handler{
		Services: s,
	}
}
