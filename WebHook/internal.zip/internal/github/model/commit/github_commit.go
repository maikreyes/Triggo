package commit

type GithubCommit struct {
	Commiter GithubCommiter
	Distinct bool
	Id       string
	Message  string
}
