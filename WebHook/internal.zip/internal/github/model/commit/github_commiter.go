package commit

type GithubCommiter struct {
	Date     string
	Email    string
	Name     string
	Username string
}
