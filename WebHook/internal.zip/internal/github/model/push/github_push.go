package push

import "triggo/internal/github/model/commit"

type GithubPush struct {
	Commit     commit.GithubCommit
	Ref        string
	Repository string
	Sender     string
}
