package services

type Services struct {
}

func NewSercies() *Services {
	return &Services{}
}
