package ports

type GithubServices interface {
	DecodeMessage(event string, body string)
}
